﻿using System.Collections.Generic;
using UnityEngine;

// ================================================================
// AlphaBetaAI - Giai doan 4
// - Paranoid alpha-beta cho nhieu nguoi choi
// - Move ordering tot hon
// - Uu tien:
//   1) nuoc thang ngay
//   2) nuoc thoat ngay
//   3) nuoc lam doi thu het nuoc / rat it nuoc
//   4) nuoc block tot
//   5) moi toi EvalFunction
// ================================================================
public class AlphaBetaAI
{
    private readonly int maxDepth;
    private readonly int myPlayerIndex;

    // Gia tri rat lon de uu tien terminal
    const int WIN_SCORE = 1000000;

    public AlphaBetaAI(int depth, int myPlayerIndex)
    {
        this.maxDepth = Mathf.Max(1, depth);
        this.myPlayerIndex = myPlayerIndex;
    }

    public GameState BestMove(GameState state)
    {
        if (state == null) return null;

        var children = DodgemRules.GetChildren(state);
        if (children == null || children.Count == 0) return null;

        OrderMoves(children);

        GameState bestChild = null;
        int bestScore = int.MinValue;

        int alpha = int.MinValue + 1;
        int beta  = int.MaxValue - 1;

        foreach (var child in children)
        {
            int score = Search(child, maxDepth - 1, alpha, beta);

            if (score > bestScore || bestChild == null)
            {
                bestScore = score;
                bestChild = child;
            }

            if (score > alpha)
                alpha = score;
        }

        return bestChild;
    }

    int Search(GameState state, int depth, int alpha, int beta)
    {
        if (depth <= 0 || state.IsTerminal())
            return EvalFunction.Eval(state, myPlayerIndex);

        var children = DodgemRules.GetChildren(state);
        if (children == null || children.Count == 0)
            return EvalFunction.Eval(state, myPlayerIndex);

        OrderMoves(children);

        bool isMyTurn = state.currentPlayerIndex == myPlayerIndex;

        if (isMyTurn)
        {
            int best = int.MinValue;

            foreach (var child in children)
            {
                int score = Search(child, depth - 1, alpha, beta);
                if (score > best) best = score;
                if (score > alpha) alpha = score;
                if (beta <= alpha) break;
            }

            return best;
        }
        else
        {
            // Paranoid: tat ca doi thu deu co xu huong giam score cua minh
            int best = int.MaxValue;

            foreach (var child in children)
            {
                int score = Search(child, depth - 1, alpha, beta);
                if (score < best) best = score;
                if (score < beta) beta = score;
                if (beta <= alpha) break;
            }

            return best;
        }
    }

    void OrderMoves(List<GameState> children)
    {
        children.Sort((a, b) =>
        {
            int sa = QuickMoveScore(a);
            int sb = QuickMoveScore(b);
            return sb.CompareTo(sa); // giam dan
        });
    }

    int QuickMoveScore(GameState state)
    {
        // 1) Terminal uu tien cao nhat
        var winner = state.Winner();
        if (winner != null)
        {
            if (winner.playerIndex == myPlayerIndex) return WIN_SCORE;
            return -WIN_SCORE;
        }

        int score = 0;

        // 2) Uu tien nuoc lam minh thoat them quan
        int myEscapedNow = state.players[myPlayerIndex].escaped;
        score += myEscapedNow * 20000;

        // 3) Uu tien neu doi thu bi het/rat it nuoc di
        int oppMobility = 0;
        int trappedOpps = 0;

        var tmp = state.Clone();
        for (int i = 0; i < state.NumPlayers; i++)
        {
            if (i == myPlayerIndex) continue;

            tmp.currentPlayerIndex = i;
            int moves = DodgemRules.GetChildren(tmp).Count;
            oppMobility += moves;
            if (moves == 0) trappedOpps++;
            else if (moves == 1) score += 500;
        }

        score += trappedOpps * 4000;
        score -= oppMobility * 10;

        // 4) Uu tien nuoc lam minh con nhieu lua chon
        tmp.currentPlayerIndex = myPlayerIndex;
        int myMobility = DodgemRules.GetChildren(tmp).Count;
        score += myMobility * 12;

        // 5) Uu tien block + eval tong quan
        score += BlockPressureScore(state, myPlayerIndex);
        score += EvalFunction.Eval(state, myPlayerIndex);

        return score;
    }

    int BlockPressureScore(GameState state, int perspectiveIdx)
    {
        int score = 0;
        var me = state.players[perspectiveIdx];

        for (int oppIdx = 0; oppIdx < state.NumPlayers; oppIdx++)
        {
            if (oppIdx == perspectiveIdx) continue;
            var opp = state.players[oppIdx];

            foreach (var oppPos in opp.pieces)
            {
                if (oppPos.x == -1) continue;
                if (!state.IsCellPlayable(oppPos)) continue;

                Vector2Int fwd = opp.ForwardDir();
                Vector2Int front1 = oppPos + fwd;
                Vector2Int front2 = oppPos + fwd + fwd;

                foreach (var myPos in me.pieces)
                {
                    if (myPos.x == -1) continue;

                    if (myPos == front1) score += 220;
                    else if (myPos == front2) score += 90;
                }
            }
        }

        return score;
    }
}