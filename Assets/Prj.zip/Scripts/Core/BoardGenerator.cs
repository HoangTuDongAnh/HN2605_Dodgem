﻿using UnityEngine;
using System.Collections.Generic;

public class BoardGenerator : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject cellPrefab;
    public GameObject exitCellPrefab;

    [Header("Layout")]
    public float cellSize      = 2f;
    public float exitThickness = 2f;

    public GameObject[] Cells     { get; private set; }
    public GameObject[] ExitCells { get; private set; }
    public int          BoardSize { get; private set; }

    private List<GameObject> spawnedObjects = new List<GameObject>();

    public void Generate(GameState state)
    {
        // FIX: Dung DestroyImmediate de xoa ngay lap tuc truoc khi sinh moi
        // Tranh truong hop Destroy() defer khien cell cu con ton tai khi Generate() chay
        ClearImmediate();

        int N = state.boardSize;
        BoardSize = N;

        Cells = new GameObject[N * N];
        for (int y = 0; y < N; y++)
        {
            for (int x = 0; x < N; x++)
            {
                // Instantiate voi transform la parent de cell la con cua Board object
                var cell = Instantiate(cellPrefab, transform);
                cell.name = $"Cell_{x}{y}";
                cell.transform.localPosition = GridToLocal(new Vector2Int(x, y), N);

                var cc = cell.GetComponent<CellClick>();
                if (cc != null) cc.gridPos = new Vector2Int(x, y);

                Cells[y * N + x] = cell;
                spawnedObjects.Add(cell);
            }
        }

        ExitCells = new GameObject[state.NumPlayers];
        for (int p = 0; p < state.NumPlayers; p++)
        {
            var player = state.players[p];
            if (player.type != PlayerType.Human) continue;

            var exitCell = CreateExitCell(player, N);
            ExitCells[p] = exitCell;
            spawnedObjects.Add(exitCell);
        }
    }

    GameObject CreateExitCell(PlayerData player, int N)
    {
        var exit = Instantiate(exitCellPrefab, transform);
        exit.name = $"ExitCell_P{player.playerIndex}";
        exit.SetActive(false);

        float boardHalf = (N - 1) / 2f * cellSize;
        float dist      = boardHalf + cellSize;

        Vector3 localPos = Vector3.zero;
        Vector3 scale    = Vector3.one;

        switch (player.escapeDir)
        {
            case EscapeDirection.Top:
                localPos = new Vector3(0, dist, 0);
                scale    = new Vector3(N * cellSize, exitThickness, 1f);
                break;
            case EscapeDirection.Right:
                localPos = new Vector3(dist, 0, 0);
                scale    = new Vector3(exitThickness, N * cellSize, 1f);
                break;
            case EscapeDirection.Left:
                localPos = new Vector3(-dist, 0, 0);
                scale    = new Vector3(exitThickness, N * cellSize, 1f);
                break;
            case EscapeDirection.Bottom:
                localPos = new Vector3(0, -dist, 0);
                scale    = new Vector3(N * cellSize, exitThickness, 1f);
                break;
        }

        exit.transform.localPosition = localPos;
        exit.transform.localScale    = scale;

        var cc = exit.GetComponent<CellClick>();
        if (cc != null)
        {
            switch (player.escapeDir)
            {
                case EscapeDirection.Top:    cc.gridPos = new Vector2Int(0,  N);  break;
                case EscapeDirection.Right:  cc.gridPos = new Vector2Int(N,  0);  break;
                case EscapeDirection.Left:   cc.gridPos = new Vector2Int(-1, 0);  break;
                case EscapeDirection.Bottom: cc.gridPos = new Vector2Int(0, -1);  break;
            }
        }

        return exit;
    }

    // FIX: ClearImmediate dung DestroyImmediate de xoa ngay, khong defer
    public void ClearImmediate()
    {
        foreach (var go in spawnedObjects)
        {
            if (go != null)
            {
                if (Application.isPlaying)
                    Destroy(go);
                else
                    DestroyImmediate(go);
            }
        }
        spawnedObjects.Clear();
        Cells     = null;
        ExitCells = null;
        BoardSize = 0;

        // Xoa them cac con con lai cua Board object (neu co cell cu tu version truoc)
        // Chay nguoc de tranh index shift
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            var child = transform.GetChild(i).gameObject;
            if (Application.isPlaying)
                Destroy(child);
            else
                DestroyImmediate(child);
        }
    }

    // Giu lai Clear() cu de backward-compat
    public void Clear() => ClearImmediate();

    // LocalPosition thay vi world position (vi cell la con cua Board)
    public Vector3 GridToLocal(Vector2Int grid, int boardSize)
    {
        float offset = (boardSize - 1) / 2f * cellSize;
        return new Vector3(grid.x * cellSize - offset,
                           grid.y * cellSize - offset, 0f);
    }

    // GridToWorld tinh tu world position cua Board object
    public Vector3 GridToWorld(Vector2Int grid, int boardSize)
    {
        return transform.position + GridToLocal(grid, boardSize);
    }

    void OnDestroy() { Clear(); }
}