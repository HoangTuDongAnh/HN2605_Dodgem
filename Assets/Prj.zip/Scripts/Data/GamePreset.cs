﻿using UnityEngine;

// ================================================================
// GamePreset — ScriptableObject định nghĩa 1 cấu hình màn chơi
//
// Designer tạo preset trong Editor bằng cách:
//   1. Chuột phải → Create → Dodgem → GamePreset
//   2. Đặt tên preset (vd: "2 Nguoi - 3x3", "4 Nguoi - 5x5")
//   3. Chọn boardSize → ma trận cell[][] tự sinh
//   4. Toggle từng ô trong boardMatrix để đánh dấu vị trí xuất phát
//   5. Gán playerConfigs cho từng phe
//
// Quy ước boardMatrix:
//   - (0,0) = góc dưới trái, (N-1, N-1) = góc trên phải
//   - Mỗi ô có giá trị CellOwner: None / P0 / P1 / P2 / P3
//   - Ô nào được đánh dấu = quân xuất phát của phe đó
// ================================================================

public enum CellOwner { None, P0, P1, P2, P3 }

[System.Serializable]
public class PlayerPresetConfig
{
    public string          playerName  = "Player";
    public EscapeDirection escapeDir   = EscapeDirection.Right;
    public PlayerType      type        = PlayerType.Human;
    [Range(1, 6)]
    public int             botDepth    = 4;   // chi dung khi type = Bot
    public Color           pieceColor  = Color.white;
}

// Row wrapper de Unity Inspector hien thi 2D array dung
[System.Serializable]
public class BoardRow
{
    // Moi phan tu la CellOwner cua o (x, row_index)
    public CellOwner[] cells;

    public BoardRow(int width)
    {
        cells = new CellOwner[width];
    }
}

[CreateAssetMenu(fileName = "NewPreset", menuName = "Dodgem/GamePreset")]
public class GamePreset : ScriptableObject
{
    [Header("Thong tin hien thi trong menu")]
    public string presetName    = "2 Nguoi - 3x3";
    public string description   = "Co dien, 2 nguoi, ban co 3x3";
    [TextArea(2, 3)]
    public string rules         = "";   // ghi chu luat rieng neu co

    [Header("Board size")]
    [Range(3, 7)]
    public int boardSize = 3;

    // ── Ma tran ban co ────────────────────────────────────────────
    // boardMatrix[row][col] — row 0 = hang DUOI CUNG (y=0)
    // boardMatrix[boardSize-1][col] = hang TREN CUNG (y=N-1)
    // Dung CustomEditor de hien thi dep hon trong Inspector
    [Header("Ma tran xuat phat — (0,0) = goc duoi trai")]
    public BoardRow[] boardMatrix;

    [Header("Cau hinh tung phe (theo thu tu P0, P1, P2, P3)")]
    public PlayerPresetConfig[] playerConfigs;

    // ── Validation & auto-resize ──────────────────────────────────
    void OnValidate()
    {
        ResizeMatrix();
        ValidatePlayerConfigs();
    }

    public void ResizeMatrix()
    {
        int N = boardSize;

        // Tao lai matrix neu chua co hoac sai kich thuoc
        if (boardMatrix == null || boardMatrix.Length != N)
        {
            var old = boardMatrix;
            boardMatrix = new BoardRow[N];
            for (int row = 0; row < N; row++)
            {
                boardMatrix[row] = new BoardRow(N);
                // Giu lai du lieu cu neu co
                if (old != null && row < old.Length && old[row] != null)
                    for (int col = 0; col < N && col < old[row].cells.Length; col++)
                        boardMatrix[row].cells[col] = old[row].cells[col];
            }
        }
        else
        {
            // Chi resize hang neu do rong thay doi
            for (int row = 0; row < N; row++)
            {
                if (boardMatrix[row] == null)
                    boardMatrix[row] = new BoardRow(N);
                else if (boardMatrix[row].cells == null || boardMatrix[row].cells.Length != N)
                {
                    var oldCells = boardMatrix[row].cells;
                    boardMatrix[row].cells = new CellOwner[N];
                    if (oldCells != null)
                        for (int col = 0; col < N && col < oldCells.Length; col++)
                            boardMatrix[row].cells[col] = oldCells[col];
                }
            }
        }
    }

    void ValidatePlayerConfigs()
    {
        if (playerConfigs == null) playerConfigs = new PlayerPresetConfig[0];
    }

    // ── Helpers cho GameManager ────────────────────────────────────

    // Lay so phe (tu playerConfigs)
    public int NumPlayers => playerConfigs != null ? playerConfigs.Length : 0;

    // Lay danh sach vi tri xuat phat cua phe playerIdx tu boardMatrix
    public Vector2Int[] GetStartPositions(int playerIdx)
    {
        var list = new System.Collections.Generic.List<Vector2Int>();
        CellOwner target = (CellOwner)(playerIdx + 1); // P0=1, P1=2, P2=3, P3=4

        for (int row = 0; row < boardMatrix.Length; row++)
        {
            if (boardMatrix[row] == null) continue;
            for (int col = 0; col < boardMatrix[row].cells.Length; col++)
            {
                if (boardMatrix[row].cells[col] == target)
                {
                    // row trong matrix = y trong game (row 0 = y=0)
                    list.Add(new Vector2Int(col, row));
                }
            }
        }
        return list.ToArray();
    }

    // So quan cua phe playerIdx (doc tu matrix)
    public int GetPieceCount(int playerIdx)
        => GetStartPositions(playerIdx).Length;

    // Kiem tra preset co hop le khong
    public bool IsValid(out string error)
    {
        if (playerConfigs == null || playerConfigs.Length < 2)
        { error = "Can it nhat 2 player configs"; return false; }

        for (int i = 0; i < playerConfigs.Length; i++)
        {
            var pos = GetStartPositions(i);
            if (pos.Length == 0)
            { error = $"P{i} ({playerConfigs[i].playerName}) chua co quan nao tren matrix"; return false; }
        }
        error = "";
        return true;
    }
}