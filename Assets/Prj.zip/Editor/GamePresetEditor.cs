﻿// ================================================================
// FILE NAY PHAI NAM TRONG THU MUC: Assets/Editor/
// Khong duoc dat o ngoai folder Editor — se loi khi build
// ================================================================
#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;

// ================================================================
// GamePresetEditor — Custom Inspector cho GamePreset
//
// Hien thi boardMatrix nhu mot bang o vuong co the click de toggle:
//   - Click o trong (gray) → chuyen sang P0 (trang)
//   - Click tiep → P1 (den) → P2 (do) → P3 (xanh) → None
//
// Mau moi phe lay tu playerConfigs[i].pieceColor de nhat quan
// ================================================================

[CustomEditor(typeof(GamePreset))]
public class GamePresetEditor : Editor
{
    // Kich thuoc moi o trong matrix (pixel)
    const int CELL_SIZE    = 36;
    const int CELL_PADDING = 3;
    const int LABEL_WIDTH  = 20;  // chieu rong phan nhan hang (y index)

    // Mau nen cua o tuy theo CellOwner
    static readonly Color ColorNone = new Color(0.25f, 0.25f, 0.25f);
    static readonly Color ColorP0   = new Color(0.95f, 0.95f, 0.95f); // Trang
    static readonly Color ColorP1   = new Color(0.15f, 0.15f, 0.15f); // Den
    static readonly Color ColorP2   = new Color(0.85f, 0.2f,  0.2f);  // Do
    static readonly Color ColorP3   = new Color(0.2f,  0.6f,  0.9f);  // Xanh

    public override void OnInspectorGUI()
    {
        var preset = (GamePreset)target;
        serializedObject.Update();

        // ── Phan thong tin chung ──────────────────────────────────
        EditorGUILayout.LabelField("Thong tin", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(serializedObject.FindProperty("presetName"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("description"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("rules"));
        EditorGUILayout.Space(8);

        // ── Board size ────────────────────────────────────────────
        EditorGUI.BeginChangeCheck();
        EditorGUILayout.PropertyField(serializedObject.FindProperty("boardSize"));
        if (EditorGUI.EndChangeCheck())
        {
            serializedObject.ApplyModifiedProperties();
            preset.ResizeMatrix();
            EditorUtility.SetDirty(preset);
            serializedObject.Update();
        }
        EditorGUILayout.Space(8);

        // ── Player configs ────────────────────────────────────────
        EditorGUILayout.LabelField("Cau hinh nguoi choi", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(
            serializedObject.FindProperty("playerConfigs"), true);
        serializedObject.ApplyModifiedProperties();
        EditorGUILayout.Space(8);

        // ── Ma tran truc quan ────────────────────────────────────
        EditorGUILayout.LabelField("Ma tran xuat phat (click de toggle)", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox(
            "Gray=Trong | Mau P0/P1/P2/P3 = quan cua phe do\n" +
            "Click de chuyen: None → P0 → P1 → P2 → P3 → None",
            MessageType.Info);
        EditorGUILayout.Space(4);

        DrawMatrix(preset);

        EditorGUILayout.Space(8);

        // ── Nut tien ich ─────────────────────────────────────────
        EditorGUILayout.LabelField("Tien ich", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Xoa toan bo matrix"))
        {
            Undo.RecordObject(preset, "Clear Matrix");
            ClearMatrix(preset);
            EditorUtility.SetDirty(preset);
        }
        if (GUILayout.Button("Auto-fill 2 phe (goc cheo)"))
        {
            Undo.RecordObject(preset, "Auto Fill 2P");
            AutoFill2Player(preset);
            EditorUtility.SetDirty(preset);
        }
        if (GUILayout.Button("Auto-fill 4 phe (4 canh)"))
        {
            Undo.RecordObject(preset, "Auto Fill 4P");
            AutoFill4Player(preset);
            EditorUtility.SetDirty(preset);
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(4);

        // Kiem tra preset va hien thi ket qua
        string validError;
        if (preset.IsValid(out validError))
        {
            EditorGUILayout.HelpBox("Preset hop le!", MessageType.None);
            for (int i = 0; i < preset.NumPlayers; i++)
            {
                int count = preset.GetPieceCount(i);
                string name = (i < preset.playerConfigs.Length)
                              ? preset.playerConfigs[i].playerName : $"P{i}";
                EditorGUILayout.LabelField($"  {name}: {count} quan");
            }
        }
        else
        {
            EditorGUILayout.HelpBox("LOI: " + validError, MessageType.Error);
        }

        serializedObject.ApplyModifiedProperties();
    }

    // ── Ve ma tran ────────────────────────────────────────────────
    void DrawMatrix(GamePreset preset)
    {
        if (preset.boardMatrix == null) return;

        int N        = preset.boardSize;
        int totalW   = LABEL_WIDTH + N * (CELL_SIZE + CELL_PADDING);
        int totalH   = N * (CELL_SIZE + CELL_PADDING) + LABEL_WIDTH;

        // Reserve khong gian trong Inspector
        Rect layoutRect = GUILayoutUtility.GetRect(totalW, totalH + 8);
        float startX    = layoutRect.x + (layoutRect.width - totalW) / 2f;
        float startY    = layoutRect.y + 4;

        // Ve nhan cot (x index) — phia tren
        for (int col = 0; col < N; col++)
        {
            float cx = startX + LABEL_WIDTH + col * (CELL_SIZE + CELL_PADDING);
            var labelRect = new Rect(cx, startY, CELL_SIZE, LABEL_WIDTH - 2);
            GUI.Label(labelRect, col.ToString(),
                new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter });
        }

        // Ve tung hang (row 0 = duoi cung = y=0 → hien thi duoi cung)
        for (int row = 0; row < N; row++)
        {
            // Dao nguoc: row=0 (y=0) o duoi cung man hinh
            int displayRow = N - 1 - row;
            float cy = startY + LABEL_WIDTH + displayRow * (CELL_SIZE + CELL_PADDING);

            // Nhan hang (y index)
            var rowLabelRect = new Rect(startX, cy, LABEL_WIDTH - 2, CELL_SIZE);
            GUI.Label(rowLabelRect, row.ToString(),
                new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleRight });

            if (preset.boardMatrix[row] == null) continue;

            for (int col = 0; col < N; col++)
            {
                float cx      = startX + LABEL_WIDTH + col * (CELL_SIZE + CELL_PADDING);
                var cellRect  = new Rect(cx, cy, CELL_SIZE, CELL_SIZE);
                var owner     = preset.boardMatrix[row].cells[col];

                // Mau nen theo owner
                Color bgColor = GetOwnerColor(owner, preset);
                EditorGUI.DrawRect(cellRect, bgColor);

                // Border
                DrawBorder(cellRect, new Color(0.1f, 0.1f, 0.1f, 0.5f));

                // Label owner trong o
                string label = owner == CellOwner.None ? "" : owner.ToString();
                var labelStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment  = TextAnchor.MiddleCenter,
                    fontStyle  = FontStyle.Bold,
                    normal     = { textColor = GetContrastColor(bgColor) }
                };
                GUI.Label(cellRect, label, labelStyle);

                // Xu ly click
                if (Event.current.type == EventType.MouseDown &&
                    cellRect.Contains(Event.current.mousePosition))
                {
                    Undo.RecordObject(preset, "Toggle Cell");
                    preset.boardMatrix[row].cells[col] = NextOwner(owner, preset.NumPlayers);
                    EditorUtility.SetDirty(preset);
                    Event.current.Use();
                    Repaint();
                }
            }
        }
    }

    // Chuyen owner sang gia tri tiep theo (None→P0→P1→...→None)
    CellOwner NextOwner(CellOwner current, int numPlayers)
    {
        int next = (int)current + 1;
        // Chi cho phep den phe cuoi cung
        int maxOwner = Mathf.Min(numPlayers, 4); // P0..P(numPlayers-1)
        if (next > maxOwner) next = 0;
        return (CellOwner)next;
    }

    Color GetOwnerColor(CellOwner owner, GamePreset preset)
    {
        int idx = (int)owner - 1; // P0=0, P1=1, ...
        if (idx >= 0 && preset.playerConfigs != null && idx < preset.playerConfigs.Length)
            return preset.playerConfigs[idx].pieceColor;

        // Fallback mau mac dinh
        switch (owner)
        {
            case CellOwner.P0: return ColorP0;
            case CellOwner.P1: return ColorP1;
            case CellOwner.P2: return ColorP2;
            case CellOwner.P3: return ColorP3;
            default:           return ColorNone;
        }
    }

    // Mau chu tuong phan voi nen
    Color GetContrastColor(Color bg)
    {
        float luminance = 0.299f * bg.r + 0.587f * bg.g + 0.114f * bg.b;
        return luminance > 0.5f ? Color.black : Color.white;
    }

    void DrawBorder(Rect rect, Color color)
    {
        EditorGUI.DrawRect(new Rect(rect.x,                rect.y,                rect.width,  1), color);
        EditorGUI.DrawRect(new Rect(rect.x,                rect.y + rect.height-1,rect.width,  1), color);
        EditorGUI.DrawRect(new Rect(rect.x,                rect.y,                1, rect.height), color);
        EditorGUI.DrawRect(new Rect(rect.x + rect.width-1, rect.y,                1, rect.height), color);
    }

    // ── Auto-fill helpers ─────────────────────────────────────────

    void ClearMatrix(GamePreset preset)
    {
        if (preset.boardMatrix == null) return;
        foreach (var row in preset.boardMatrix)
            if (row?.cells != null)
                for (int i = 0; i < row.cells.Length; i++)
                    row.cells[i] = CellOwner.None;
    }

    // P0 = cot trai (x=0), P1 = hang duoi (y=0)
    // So quan = boardSize - 1
    void AutoFill2Player(GamePreset preset)
    {
        ClearMatrix(preset);
        int N = preset.boardSize;
        int pieces = N - 1; // so quan moi phe

        // P0 (Trang) — cot trai x=0, hang 1 den N-1
        for (int i = 1; i <= pieces; i++)
            if (i < N) preset.boardMatrix[i].cells[0] = CellOwner.P0;

        // P1 (Den) — hang duoi y=0, cot 1 den N-1
        for (int i = 1; i <= pieces; i++)
            if (i < N) preset.boardMatrix[0].cells[i] = CellOwner.P1;
    }

    // P0=trai, P1=duoi, P2=phai, P3=tren
    // So quan = boardSize - 1
    void AutoFill4Player(GamePreset preset)
    {
        ClearMatrix(preset);
        int N      = preset.boardSize;
        int pieces = N - 1;

        // P0 (Trang) — cot trai x=0, hang 1 den N-2
        for (int i = 1; i < N - 1; i++)
            preset.boardMatrix[i].cells[0] = CellOwner.P0;

        // P1 (Den) — hang duoi y=0, cot 1 den N-2
        for (int i = 1; i < N - 1; i++)
            preset.boardMatrix[0].cells[i] = CellOwner.P1;

        // P2 (Do) — cot phai x=N-1, hang 1 den N-2
        for (int i = 1; i < N - 1; i++)
            preset.boardMatrix[i].cells[N - 1] = CellOwner.P2;

        // P3 (Xanh) — hang tren y=N-1, cot 1 den N-2
        for (int i = 1; i < N - 1; i++)
            preset.boardMatrix[N - 1].cells[i] = CellOwner.P3;
    }
}
#endif