﻿using UnityEngine;

/// <summary>
/// AI minimax co ban, dung cho muc do de.
/// </summary>
public class MinimaxAI : IGameAI
{
    #region Fields

    private readonly int maxDepth;
    private readonly int myPlayerIndex;

    #endregion

    #region Properties

    public string DisplayName => "Minimax";

    #endregion

    #region Constructor

    /// <summary>
    /// Khoi tao AI minimax voi depth va player index.
    /// </summary>
    public MinimaxAI(int depth, int myPlayerIndex)
    {
        this.maxDepth = Mathf.Max(1, depth);
        this.myPlayerIndex = myPlayerIndex;
    }

    #endregion

    #region Public API

    /// <summary>
    /// Tim nuoc di tot nhat cho state hien tai.
    /// </summary>
    public GameState BestMove(GameState state)
    {
        if (state == null) return null;

        var children = DodgemRules.GetChildren(state);
        if (children == null || children.Count == 0) return null;

        int effectiveDepth = GetEffectiveDepth(state, children.Count);

        GameState bestState = null;
        int bestValue = int.MinValue;

        foreach (var child in children)
        {
            int value = Search(child, effectiveDepth - 1);
            if (bestState == null || value > bestValue)
            {
                bestValue = value;
                bestState = child;
            }
        }

        return bestState;
    }

    #endregion

    #region Search

    /// <summary>
    /// Duyet cay minimax theo huong paranoid.
    /// </summary>
    int Search(GameState state, int depth)
    {
        if (depth <= 0 || state.IsTerminal())
            return EvalFunction.Eval(state, myPlayerIndex);

        var children = DodgemRules.GetChildren(state);
        if (children == null || children.Count == 0)
            return EvalFunction.Eval(state, myPlayerIndex);

        bool isMyTurn = state.currentPlayerIndex == myPlayerIndex;

        if (isMyTurn)
        {
            int best = int.MinValue;
            foreach (var child in children)
            {
                int score = Search(child, depth - 1);
                if (score > best) best = score;
            }
            return best;
        }
        else
        {
            int best = int.MaxValue;
            foreach (var child in children)
            {
                int score = Search(child, depth - 1);
                if (score < best) best = score;
            }
            return best;
        }
    }

    #endregion

    #region Depth Control

    /// <summary>
    /// Dieu chinh depth thuc te de giu AI muot hon khi nhieu bot.
    /// </summary>
    int GetEffectiveDepth(GameState state, int rootMoveCount)
    {
        int depth = maxDepth;

        if (state.NumPlayers >= 3)
            depth -= 1;

        if (rootMoveCount >= 20)
            depth -= 1;

        return Mathf.Clamp(depth, 1, maxDepth);
    }

    #endregion
}