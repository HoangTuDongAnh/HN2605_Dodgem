﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Dieu phoi flow luot choi, state hien tai va dieu kien ket thuc.
/// </summary>
public class TurnFlowController
{
    #region Fields

    private readonly MonoBehaviour coroutineHost;
    private readonly BoardRenderer boardRenderer;
    private readonly GameStatusPresenter statusPresenter;
    private readonly HumanInputController humanInputController;
    private readonly BotTurnController botTurnController;
    private readonly IGameAI[] bots;

    private GameState currentState;
    private bool isAnimating;
    private int sessionVersion;

    #endregion

    #region Properties

    public GameState CurrentState => currentState;
    public bool IsAnimating => isAnimating;

    #endregion

    #region Constructor

    /// <summary>
    /// Khoi tao flow controller voi cac dependency can thiet.
    /// </summary>
    public TurnFlowController(
        MonoBehaviour coroutineHost,
        BoardRenderer boardRenderer,
        GameStatusPresenter statusPresenter,
        HumanInputController humanInputController,
        BotTurnController botTurnController,
        IGameAI[] bots)
    {
        this.coroutineHost = coroutineHost;
        this.boardRenderer = boardRenderer;
        this.statusPresenter = statusPresenter;
        this.humanInputController = humanInputController;
        this.botTurnController = botTurnController;
        this.bots = bots;
    }

    #endregion

    #region Public API

    /// <summary>
    /// Bat dau van dau moi voi state ban dau.
    /// </summary>
    public void StartGame(GameState initialState)
    {
        sessionVersion++;
        currentState = initialState;
        isAnimating = false;

        humanInputController?.ClearSelection();
        boardRenderer?.Render(currentState);

        coroutineHost.StartCoroutine(HandleTurn(sessionVersion));
    }

    /// <summary>
    /// Xu ly click o board cua human.
    /// </summary>
    public void HandleHumanClick(Vector2Int pos)
    {
        if (isAnimating || currentState == null) return;
        if (currentState.CurrentPlayer.type != PlayerType.Human) return;

        var nextState = humanInputController.HandleCellClick(currentState, boardRenderer, pos);
        if (nextState == null) return;

        ApplyHumanMove(nextState, sessionVersion);
    }

    #endregion

    #region Turn Flow

    /// <summary>
    /// Dieu phoi luot choi hien tai.
    /// </summary>
    IEnumerator HandleTurn(int version)
    {
        while (true)
        {
            if (version != sessionVersion)
                yield break;

            if (currentState == null)
                yield break;

            var player = currentState.CurrentPlayer;
            var ai = (bots != null && player.playerIndex < bots.Length) ? bots[player.playerIndex] : null;

            statusPresenter?.ShowTurnStatus(player, ai);
            boardRenderer?.Render(currentState);

            if (player.type == PlayerType.Bot)
            {
                yield return coroutineHost.StartCoroutine(HandleBotTurn(version));

                if (version != sessionVersion)
                    yield break;

                if (CheckWinCondition())
                    yield break;
            }
            else
            {
                yield break;
            }
        }
    }

    /// <summary>
    /// Xu ly luot di cua bot.
    /// </summary>
    IEnumerator HandleBotTurn(int version)
    {
        if (version != sessionVersion)
            yield break;

        if (botTurnController == null || currentState == null)
            yield break;

        isAnimating = true;

        GameState appliedState = currentState;
        bool stateApplied = false;

        yield return coroutineHost.StartCoroutine(
            botTurnController.ExecuteBotTurn(
                currentState,
                nextState =>
                {
                    appliedState = nextState;
                    stateApplied = true;
                }
            )
        );

        if (version != sessionVersion)
            yield break;

        if (stateApplied)
            currentState = appliedState;

        isAnimating = false;
        ContinueTurn(version);
    }

    /// <summary>
    /// Tiep tuc sang luot ke tiep sau khi hoan tat nuoc di.
    /// </summary>
    void ContinueTurn(int version)
    {
        if (version != sessionVersion)
            return;

        humanInputController?.ClearSelection();
        boardRenderer?.Render(currentState);

        if (CheckWinCondition())
            return;

        coroutineHost.StartCoroutine(HandleTurn(version));
    }

    #endregion

    #region Human Move

    /// <summary>
    /// Thuc thi nuoc di cua human.
    /// </summary>
    void ApplyHumanMove(GameState nextState, int version)
    {
        if (version != sessionVersion)
            return;

        isAnimating = true;

        GameState oldState = currentState;
        currentState = nextState;

        humanInputController?.ClearSelection();
        coroutineHost.StartCoroutine(HumanMoveCoroutine(oldState, nextState, version));
    }

    /// <summary>
    /// Chay animation sau nuoc di cua human.
    /// </summary>
    IEnumerator HumanMoveCoroutine(GameState oldState, GameState nextState, int version)
    {
        yield return coroutineHost.StartCoroutine(boardRenderer.RenderAnimated(oldState, nextState));

        if (version != sessionVersion)
            yield break;

        isAnimating = false;
        ContinueTurn(version);
    }

    #endregion

    #region Win Check

    /// <summary>
    /// Kiem tra dieu kien ket thuc van dau.
    /// </summary>
    bool CheckWinCondition()
    {
        if (currentState == null) return false;

        var winner = currentState.Winner();
        if (winner != null)
        {
            statusPresenter?.ShowWinner(winner);
            return true;
        }

        return false;
    }

    #endregion
}