using UnityEngine;

/// <summary>
/// Luu tru trang thai runtime cua van dau.
/// </summary>
[System.Serializable]
public class GameState
{
    #region Fields

    public int boardWidth;
    public int boardHeight;
    public PlayerData[] players;
    public int currentPlayerIndex;

    [Header("Mask o hop le tren ban")]
    public bool[,] validCells;

    #endregion

    #region Properties

    public int NumPlayers => players != null ? players.Length : 0;
    public PlayerData CurrentPlayer => players[currentPlayerIndex];

    #endregion

    #region Public Methods

    /// <summary>
    /// Tao ban sao state hien tai de phuc vu AI/search.
    /// </summary>
    public GameState Clone()
    {
        var clonedPlayers = new PlayerData[players.Length];
        for (int i = 0; i < players.Length; i++)
            clonedPlayers[i] = players[i].Clone();

        bool[,] clonedValidCells = null;
        if (validCells != null)
        {
            clonedValidCells = new bool[boardWidth, boardHeight];
            for (int x = 0; x < boardWidth; x++)
            {
                for (int y = 0; y < boardHeight; y++)
                    clonedValidCells[x, y] = validCells[x, y];
            }
        }

        return new GameState
        {
            boardWidth = boardWidth,
            boardHeight = boardHeight,
            players = clonedPlayers,
            currentPlayerIndex = currentPlayerIndex,
            validCells = clonedValidCells
        };
    }

    /// <summary>
    /// Kiem tra state da ket thuc hay chua.
    /// </summary>
    public bool IsTerminal()
    {
        foreach (var player in players)
        {
            if (player.HasWon())
                return true;
        }

        return !DodgemRules.HasAnyLegalMove(this, currentPlayerIndex);
    }

    /// <summary>
    /// Lay nguoi thang neu state da ket thuc.
    /// </summary>
    public PlayerData Winner()
    {
        foreach (var player in players)
        {
            if (player.HasWon())
                return player;
        }

        if (!DodgemRules.HasAnyLegalMove(this, currentPlayerIndex))
        {
            int previous = (currentPlayerIndex - 1 + NumPlayers) % NumPlayers;
            return players[previous];
        }

        return null;
    }

    /// <summary>
    /// Kiem tra co quan nao dang chiem o nay hay khong.
    /// </summary>
    public bool IsOccupied(Vector2Int pos)
    {
        foreach (var player in players)
        {
            if (player.HasPieceAt(pos))
                return true;
        }

        return false;
    }

    /// <summary>
    /// Kiem tra o nay co hop le de dung/di chuyen hay khong.
    /// </summary>
    public bool IsCellPlayable(Vector2Int pos)
    {
        if (pos.x < 0 || pos.x >= boardWidth || pos.y < 0 || pos.y >= boardHeight)
            return false;

        if (validCells == null)
            return true;

        return validCells[pos.x, pos.y];
    }

    /// <summary>
    /// Chuyen sang luot nguoi choi tiep theo.
    /// </summary>
    public void NextTurn()
    {
        currentPlayerIndex = (currentPlayerIndex + 1) % NumPlayers;
    }

    #endregion
}